export { JSEncrypt } from "./JSEncrypt";
import { JSEncrypt } from "./JSEncrypt";
export default JSEncrypt;
